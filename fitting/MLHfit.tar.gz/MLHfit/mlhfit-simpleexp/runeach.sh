for i in {1..500}
do
	root -b -q  "gensim.C()"
	root -b -q  "mlhfitsim.C()"
done
